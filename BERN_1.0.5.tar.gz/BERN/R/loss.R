hubercls <- function(r, delta) {
  (1 - r ) * (r < 1 - delta) + ((1 - r + delta)^4/2 - (1 - r - delta)*(1 - r + delta )^3)/ (8 * delta^3) * (r <= 1 + delta) * (r >= 1 - delta)
} 




