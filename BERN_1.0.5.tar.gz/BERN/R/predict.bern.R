predict.bern <- function(object, newx, s = NULL, 
    type = c("class", "link"), ...) NextMethod("predict") 
